// Example: Add a small interaction effect
document.addEventListener("DOMContentLoaded", function() {
    console.log("Website Loaded Successfully!");
});
// Smooth Scroll to Sections
function scrollToSection(sectionId) {
    document.getElementById(sectionId).scrollIntoView({ behavior: 'smooth' });
}

// Form Submission Alert
document.querySelector('.order-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert("Your order has been placed successfully!");
});
// Fade-in on scroll
window.addEventListener("scroll", function () {
    let contact = document.getElementById("contact");
    let position = contact.getBoundingClientRect().top;
    let screenPos = window.innerHeight / 1.3;

    if (position < screenPos) {
        contact.classList.add("show");
    }
});

// Click to copy function
function copyText(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert("Copied: " + text);
    });
}